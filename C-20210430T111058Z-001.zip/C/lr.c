#include<stdio.h>
#include<conio.h>
void main()
{
	int num1, num2, num3,largest,smallest;
	printf("Enter 3 number to compare:");
	scanf("%d %d %d" ,&num1, &num2, &num3);
	if(num1<num2)
	{
		smallest = num1;
		largest = num2;
	}
	else{
		largest = num1; 
		smallest = num2; 
	}
 	if(num3>largest)
 	{
 		largest = num3;
 		} else if(num3<smallest)
{
 		smallest = num3;
 		}
 		printf("The largest and smallest among %d %d %d is %d and %d",num1, num2, num3, largest,smallest);
 	if(largest%2==0)
{
 		printf("%d is even number",largest);
}
else{ 
  printf("%d is odd number",largest);
     }
 getch();
}

 
 