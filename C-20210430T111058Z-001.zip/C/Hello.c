//Simple C program to display "Hello World"
//Header file for input output functions
#include<stdio.h>
#include<conio.h>

//main function-
//where the execution of program begins
void main()
{
    /*printf displays the content
     *passed between the double quotes.
    */
     printf("Hello world!");
    getch();
}