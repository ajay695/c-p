#include<stdio.h>
#include<conio.h>
void main()
{
float a=2.4,b=1.12,c;
// Calculating division
c=a/b;
// %.2lf displays number up to 2 decimal point
printf("The division of %.2f and %.2f is %.2f", a,b,c);
getch();
}
    