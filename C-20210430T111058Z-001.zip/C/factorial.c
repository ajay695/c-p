#include<stdio.h>
#include<conio.h>
void main()
{
 long int f=1;
      int i;
  for (i=1;i<=5;i++)
{
  f=f*i;
printf("\nThe factorial of %d is %d", i,f);
}
getch();
}
    