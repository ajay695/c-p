#include<stdio.h>
#include<conio.h>
void main()
{
float a=2.4,b=1.12,c;
c=a/b;
printf("The division of %f and %f is %f", a,b,c);
getch();
}
    